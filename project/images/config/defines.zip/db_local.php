<?php
// 本地环境配置
   // return [
   //     'class' => 'yii\db\Connection',
   //     'dsn' => 'mysql:host=182.92.80.211;dbname=xhh_merchant',
   //     'username' => 'xhhadmin',
   //     'password' => 'Xhuahua#Db!332',
   //     'charset' => 'utf8',
   //     'tablePrefix' => 'mer_'
   // ];

return [
	'class' => 'yii\db\Connection',
	'dsn' => 'mysql:host=localhost;dbname=xhh_merchant',
	'username' => 'root',
	'password' => '123!@#',
	'charset' => 'utf8',
	'tablePrefix' => 'mer_'
];
