<?php
/**
 * 此文件是唯一确定生产，测试，本地不同的文件。除此之外。其它所有文件无论生产，测试本地代码必须完全相同.
 * 需要设置为忽略状态，不可上传版本库中
 * 首次需要手动添加服务器需要将这个文件忽略，另外权限设置为不可更改，以免造成非人为错误
 */
define('SYSTEM_PROD', false); // true 代表生产环境。否则为测试

if(SYSTEM_PROD){
  // 生产环境下
  define('YII_ENV', 'prod'); // prod dev //@todo
  define('SYSTEM_DB', 'db');
}else{
  // 测试环境下
  define('YII_ENV', 'dev'); // prod dev
  define('SYSTEM_DB', 'db_local'); //取db, db_test, db_local三值之一， 分别代表生产，测试和本地数据库

  //error_reporting(E_ALL & ~E_NOTICE);
  error_reporting(E_ALL);
  define('YII_DEBUG', true);
}
