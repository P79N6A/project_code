<?php
// 生产环境配置
return [
    // 开发平台生产数据库
	'xhh_open' =>[
		'class' => 'yii\db\Connection',
		'dsn' => 'mysql:host=182.92.80.211;dbname=xhh_open',
		'username' => 'xhhadmin',
		'password' => 'Xhuahua#Db!332',
		'charset' => 'utf8',
		'tablePrefix' => 'xhh_',
    ],
    //一亿元
    'xhh_yyy' => [
        'class' => 'yii\db\Connection',
        'dsn' => 'mysql:host=182.92.80.211;dbname=xhh_test',
        'username' => 'xhhadmin',
        'password' => 'Xhuahua#Db!332',
        'charset' => 'utf8',
        'tablePrefix' => 'yi_',
    ],
];
