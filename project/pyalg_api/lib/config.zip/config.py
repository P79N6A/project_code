# -*- coding: utf-8 -*-
class Config(object):
    # 公共配置
    DEBUG = False
    TESTING = False
    # SQLAlchemy settings
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    # SQLALCHEMY_ECHO = True
    
    # Flask-Restplus settings
    RESTPLUS_SWAGGER_UI_DOC_EXPANSION = 'list'
    RESTPLUS_VALIDATE = True
    RESTPLUS_MASK_SWAGGER = False
    RESTPLUS_ERROR_404_HELP = False

    #加密key
    SECRET_KEY = 'spLu1bSt3jXPY8ximZUf9k7F'


class ProductionConfig(Config):
    # 生产配置
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://user:pass@host/db'
    SQLALCHEMY_BINDS = {
        "xhh_antifraud": "mysql+pymysql://xhh_antifraud:QorLjwGt40C3@rdsvfjabqniybn3.mysql.rds.aliyuncs.com/xhh_antifraud",
        "xhh_open": "mysql+pymysql://xhh_open:OpenApi_php@XHH@rdsvfjabqniybn3.mysql.rds.aliyuncs.com/xhh_open",
        "xhh_yiyiyuan": "mysql+pymysql://xhh_yyy:Xhhyyy_SAderTaJSDYJ8SnTuhr5@rdsvfjabqniybn3.mysql.rds.aliyuncs.com/xhh_yiyiyuan",
        "own_yiyiyuan": "mysql+pymysql://own_yiyiyuan:We_need_DB_4_yyy@10.139.102.5/own_yiyiyuan",
        "sparrow": "mysql+pymysql://xhh_r:y@=xOg6GkCWrjMg4@10.253.42.78:8066/sparrow",
    }


class DevelopmentConfig(Config):
    # 开发配置
    DEBUG = True
    TESTING = True
    LOG_LEVEL = 'debug'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://user:pass@host/db'
    SQLALCHEMY_BINDS = {
        "xhh_antifraud": "mysql+pymysql://xhhadmin:Xhuahua#Db!332@182.92.80.211/xhh_antifraud",
        "xhh_open": "mysql+pymysql://xhhadmin:Xhuahua#Db!332@182.92.80.211/xhh_open",
        "xhh_yiyiyuan": "mysql+pymysql://xhhadmin:Xhuahua#Db!332@182.92.80.211/xhh_test",
        "own_yiyiyuan": "mysql+pymysql://xhhadmin:Xhuahua#Db!332@182.92.80.211/xhh_test"
    }

def get_config():
    # 获取配置,修改这个, 就可以切换生产,测试和本地
    return ProductionConfig
    # return DevelopmentConfig
