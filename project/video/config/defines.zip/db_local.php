<?php
// 本地环境配置
return [
	'class' => 'yii\db\Connection',
	'dsn' => 'mysql:host=localhost;dbname=xhh_open',
	'username' => 'root',
	'password' => '123!@#',
	'charset' => 'utf8',
	'tablePrefix' => 'xhh_'
];
